﻿namespace CoinWebAPI.Services
{
    public class ExchangeRate
    {
        public string Code { get; set; }
        public double Rate { get; set; }
    }
}